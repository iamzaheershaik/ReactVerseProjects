import "./App.css";
import Countercomp from "./components/counter";
function App() {
  return (
    <>
      <Countercomp />
    </>
  );
}

export default App;
