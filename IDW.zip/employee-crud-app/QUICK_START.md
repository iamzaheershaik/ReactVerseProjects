# 🚀 Quick Start Guide - Employee CRUD App

## What You've Got

A complete React application with:
- ✅ Employee management (Add, Edit, Delete, View)
- ✅ Beautiful gradient UI design
- ✅ Session storage for data persistence
- ✅ Beginner-friendly code with comments
- ✅ Reusable components

## File Structure Overview

```
employee-crud-app/
│
├── src/
│   ├── components/               # Reusable components folder
│   │   ├── EmployeeForm.jsx     # Form to add/edit employees
│   │   ├── EmployeeList.jsx     # Shows all employees
│   │   ├── EmployeeCard.jsx     # Individual employee card
│   │   └── EmployeeCard.css     # Card styling
│   │
│   ├── App.jsx                  # Main app (CRUD logic here!)
│   ├── App.css                  # Global styles
│   └── main.jsx                 # Entry point
│
├── package.json                 # All dependencies listed
├── vite.config.js              # Vite configuration
├── index.html                  # HTML template
└── README.md                   # Full documentation
```

## 3 Simple Steps to Run

### Step 1: Open Terminal in Project Folder
```bash
cd employee-crud-app
```

### Step 2: Install Packages
```bash
npm install
```
This installs:
- React & React DOM
- Vite (build tool)
- React Bootstrap
- Bootstrap CSS
- React Icons

### Step 3: Start Development Server
```bash
npm run dev
```

Then open: http://localhost:5173

## How It Works (For Beginners)

### 1. Session Storage
```javascript
// Saving data
sessionStorage.setItem('employees', JSON.stringify(employees));

// Loading data
const saved = sessionStorage.getItem('employees');
```

### 2. useState Hook
```javascript
// Creates a state variable
const [employees, setEmployees] = useState([]);

// Update state
setEmployees([...employees, newEmployee]);
```

### 3. useEffect Hook
```javascript
// Runs when component loads
useEffect(() => {
  // Load from session storage
}, []);

// Runs when employees change
useEffect(() => {
  // Save to session storage
}, [employees]);
```

### 4. Component Communication
```
App.jsx (Parent)
    ↓ passes data
EmployeeForm.jsx
    ↓ sends back data via callback
App.jsx updates state
    ↓ passes updated data
EmployeeList.jsx
    ↓ maps and creates
EmployeeCard.jsx (for each employee)
```

## Key Features Explained

### CRUD Operations in App.jsx

**CREATE** - Add new employee
```javascript
const newEmployee = { ...employeeData, id: Date.now() };
setEmployees([...employees, newEmployee]);
```

**READ** - Display all employees
```javascript
<EmployeeList employees={employees} />
```

**UPDATE** - Edit existing employee
```javascript
const updated = employees.map(emp => 
  emp.id === editingEmployee.id ? newData : emp
);
```

**DELETE** - Remove employee
```javascript
const filtered = employees.filter(emp => emp.id !== id);
setEmployees(filtered);
```

## Customization Ideas

### 1. Add More Fields
In EmployeeForm.jsx, add:
```javascript
<Form.Group>
  <Form.Label>Address</Form.Label>
  <Form.Control name="address" />
</Form.Group>
```

### 2. Change Colors
In App.css, modify:
```css
background: linear-gradient(135deg, #yourColor1 0%, #yourColor2 100%);
```

### 3. Add Search Feature
In App.jsx:
```javascript
const [searchTerm, setSearchTerm] = useState('');
const filtered = employees.filter(emp => 
  emp.name.toLowerCase().includes(searchTerm.toLowerCase())
);
```

### 4. Add Sorting
```javascript
const sorted = [...employees].sort((a, b) => 
  a.name.localeCompare(b.name)
);
```

## Common Beginner Mistakes to Avoid

❌ Forgetting to spread existing data
```javascript
setEmployees(newEmployee); // WRONG - replaces all
setEmployees([...employees, newEmployee]); // CORRECT
```

❌ Mutating state directly
```javascript
employees.push(newEmployee); // WRONG
setEmployees([...employees, newEmployee]); // CORRECT
```

❌ Not handling undefined in useEffect
```javascript
useEffect(() => {
  if (editingEmployee) { // Check first!
    setFormData(editingEmployee);
  }
}, [editingEmployee]);
```

## Packages Used

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^18.2.0 | UI library |
| react-dom | ^18.2.0 | React for web |
| vite | ^5.0.8 | Build tool (faster than webpack!) |
| react-bootstrap | ^2.9.1 | Bootstrap components |
| bootstrap | ^5.3.2 | CSS framework |
| react-icons | ^4.12.0 | Icon library |

## Testing Your App

1. **Add Employee** - Fill form and click "Add Employee"
2. **Edit Employee** - Click "Edit" on any card
3. **Delete Employee** - Click "Delete" and confirm
4. **Refresh Page** - Data should persist (session storage)
5. **Close Tab** - Data will be lost (session storage behavior)

## Want to Use LocalStorage Instead?

Just change in App.jsx:
```javascript
// Change from
sessionStorage.setItem()
sessionStorage.getItem()

// To
localStorage.setItem()
localStorage.getItem()
```

## Build for Production

When ready to deploy:
```bash
npm run build
```

This creates a `dist` folder with optimized files!

## Next Steps to Learn More

1. Add validation (email format, phone format)
2. Add search and filter functionality
3. Add pagination (show 10 employees per page)
4. Connect to a real backend API
5. Add user authentication
6. Use React Router for multiple pages

## Need Help?

- Check the full README.md for detailed documentation
- Review code comments in each file
- Use browser console (F12) to debug
- Check React DevTools extension

---

**Remember**: This is a learning project. Don't worry about making mistakes - that's how you learn! 

Happy coding! 💻✨
