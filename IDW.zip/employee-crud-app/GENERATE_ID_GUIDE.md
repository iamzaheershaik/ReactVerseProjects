# 🆔 Generate Unique ID - Package Guide

## What Changed?

The project now uses the **`generate-unique-id`** npm package instead of `Date.now()` for generating employee IDs.

---

## 📦 Package Information

**Package:** `generate-unique-id`  
**Version:** 2.0.3  
**Purpose:** Generate unique IDs with custom options

---

## 🔧 How It's Used in the Project

### Location: `src/App.jsx`

```javascript
// Import at the top
import generateUniqueId from 'generate-unique-id';

// Usage in handleSubmit function
const newEmployee = {
  ...employeeData,
  id: generateUniqueId() // Generates unique ID
};
```

---

## 🎯 What IDs Look Like

### Default Usage (What We're Using)
```javascript
generateUniqueId()
// Output: "jz8a7p2q"
```

### With Custom Options
```javascript
// Longer ID
generateUniqueId({ length: 15 })
// Output: "abc123def456ghi"

// Include specific characters
generateUniqueId({ 
  length: 10,
  useLetters: true,
  useNumbers: true
})
// Output: "a1b2c3d4e5"

// Only numbers
generateUniqueId({ 
  length: 8,
  useLetters: false,
  useNumbers: true
})
// Output: "12345678"

// Only letters
generateUniqueId({ 
  length: 8,
  useLetters: true,
  useNumbers: false
})
// Output: "abcdefgh"

// Uppercase letters only
generateUniqueId({ 
  length: 10,
  useLetters: true,
  useNumbers: false,
  upperCase: true
})
// Output: "ABCDEFGHIJ"

// Exclude specific characters
generateUniqueId({ 
  length: 10,
  excludeSymbols: ['0', 'O', '1', 'l', 'I']
})
// Output: "a2b3c4d5e6" (avoids confusing characters)
```

---

## 📊 Comparison with Date.now()

| Feature | `Date.now()` | `generate-unique-id` |
|---------|--------------|----------------------|
| **Output** | `1708123456789` | `jz8a7p2q` |
| **Length** | Always 13 digits | Customizable |
| **Format** | Numbers only | Letters + Numbers |
| **Readable** | ❌ Hard to read | ✅ Easy to read |
| **Collision Risk** | Low (time-based) | Very Low |
| **Package Needed** | ❌ No | ✅ Yes |

---

## ⚙️ Configuration Options

### Available Options

```javascript
generateUniqueId({
  length: 10,              // Length of ID (default: 8)
  useLetters: true,        // Include letters (default: true)
  useNumbers: true,        // Include numbers (default: true)
  upperCase: false,        // Use uppercase (default: false)
  excludeSymbols: [],      // Characters to exclude
})
```

---

## 🚀 How to Customize in Your Project

If you want to change the ID format, edit `src/App.jsx`:

### Example 1: Longer IDs
```javascript
const newEmployee = {
  ...employeeData,
  id: generateUniqueId({ length: 15 })
};
```

### Example 2: Numbers Only (Like Employee Number)
```javascript
const newEmployee = {
  ...employeeData,
  id: generateUniqueId({ 
    length: 6,
    useLetters: false,
    useNumbers: true
  })
};
// Output: "123456"
```

### Example 3: Employee Code Format (EMP-XXXXX)
```javascript
const employeeCode = 'EMP-' + generateUniqueId({ 
  length: 5,
  useLetters: false,
  useNumbers: true
});

const newEmployee = {
  ...employeeData,
  id: employeeCode
};
// Output: "EMP-12345"
```

### Example 4: Uppercase Letters Only
```javascript
const newEmployee = {
  ...employeeData,
  id: generateUniqueId({ 
    length: 8,
    useLetters: true,
    useNumbers: false,
    upperCase: true
  })
};
// Output: "ABCDEFGH"
```

---

## 💡 Why This Package?

### Advantages ✅
1. **Readable IDs** - Shorter and easier to read than timestamps
2. **Customizable** - You can control length and format
3. **Professional** - Looks more like real employee IDs
4. **Collision-resistant** - Very unlikely to generate duplicates
5. **Flexible** - Can create different formats for different needs

### When to Use
- ✅ Employee management systems
- ✅ User registration systems
- ✅ Product catalogs
- ✅ Order tracking
- ✅ Any app needing readable IDs

---

## 🔄 Installation & Setup

When you set up the project:

```bash
# Navigate to project
cd employee-crud-app

# Install all dependencies (includes generate-unique-id)
npm install

# Run the project
npm run dev
```

The package is automatically installed with all other dependencies!

---

## 📝 Example Employee Objects

### With generate-unique-id (Current)
```javascript
{
  id: "jz8a7p2q",
  name: "John Doe",
  email: "john@example.com",
  phone: "1234567890",
  position: "Software Engineer",
  department: "IT",
  salary: "75000"
}
```

### With Date.now() (Old)
```javascript
{
  id: 1708123456789,
  name: "John Doe",
  email: "john@example.com",
  phone: "1234567890",
  position: "Software Engineer",
  department: "IT",
  salary: "75000"
}
```

---

## 🎨 Advanced Customization Ideas

### 1. Department-Based IDs
```javascript
const deptCode = {
  'IT': 'IT',
  'HR': 'HR',
  'Finance': 'FIN',
  'Marketing': 'MKT',
  'Sales': 'SLS',
  'Operations': 'OPS'
};

const newEmployee = {
  ...employeeData,
  id: deptCode[employeeData.department] + '-' + generateUniqueId({ length: 4 })
};
// Output: "IT-a1b2" or "HR-c3d4"
```

### 2. Year-Based IDs
```javascript
const year = new Date().getFullYear();
const newEmployee = {
  ...employeeData,
  id: year + '-' + generateUniqueId({ length: 6 })
};
// Output: "2024-abc123"
```

### 3. Sequential Style IDs
```javascript
const count = employees.length + 1;
const paddedNum = String(count).padStart(4, '0');
const newEmployee = {
  ...employeeData,
  id: 'EMP-' + paddedNum + '-' + generateUniqueId({ length: 3 })
};
// Output: "EMP-0001-a1b" or "EMP-0142-x9z"
```

---

## 📚 Package Documentation

**Official Repo:** [generate-unique-id on npm](https://www.npmjs.com/package/generate-unique-id)

---

## 🐛 Troubleshooting

### Error: "generateUniqueId is not a function"
**Solution:** Make sure you installed dependencies
```bash
npm install
```

### Error: Cannot find module 'generate-unique-id'
**Solution:** Check if the package is in package.json, then run:
```bash
npm install
```

### IDs are too short/long
**Solution:** Adjust the length parameter:
```javascript
generateUniqueId({ length: 12 }) // Longer
generateUniqueId({ length: 6 })  // Shorter
```

---

## 🎯 Summary

✅ **Package Added:** `generate-unique-id` v2.0.3  
✅ **Updated File:** `src/App.jsx`  
✅ **Import Added:** `import generateUniqueId from 'generate-unique-id'`  
✅ **Usage:** `id: generateUniqueId()`  
✅ **Benefit:** Shorter, more readable employee IDs

Now your employee IDs will look like: **"jz8a7p2q"** instead of **"1708123456789"**! 🎉

---

**Happy Coding!** 💻✨
