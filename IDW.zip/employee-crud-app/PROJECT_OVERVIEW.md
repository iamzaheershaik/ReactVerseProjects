# 📊 Employee CRUD - Project Overview

## Visual Component Hierarchy

```
┌─────────────────────────────────────────────────────────┐
│                      App.jsx                            │
│  (Main component - holds all state & CRUD logic)        │
│                                                         │
│  State:                                                 │
│  • employees[]         (all employee data)              │
│  • editingEmployee     (employee being edited)          │
│                                                         │
│  Functions:                                             │
│  • handleSubmit()      (add or update employee)         │
│  • handleEdit()        (start editing)                  │
│  • handleDelete()      (remove employee)                │
│  • handleCancelEdit()  (cancel editing)                 │
└────────────┬────────────────────────────┬───────────────┘
             │                            │
             │                            │
    ┌────────▼─────────┐         ┌────────▼──────────┐
    │ EmployeeForm.jsx │         │ EmployeeList.jsx  │
    │                  │         │                   │
    │ Props received:  │         │ Props received:   │
    │ • onSubmit       │         │ • employees[]     │
    │ • editingEmployee│         │ • onEdit          │
    │ • onCancelEdit   │         │ • onDelete        │
    │                  │         │                   │
    │ Local State:     │         └──────────┬────────┘
    │ • formData       │                    │
    └──────────────────┘                    │
                                   ┌────────▼────────┐
                                   │ EmployeeCard.jsx│
                                   │                 │
                                   │ Props received: │
                                   │ • employee      │
                                   │ • onEdit        │
                                   │ • onDelete      │
                                   │                 │
                                   │ (Repeats for    │
                                   │  each employee) │
                                   └─────────────────┘
```

## Data Flow Diagram

```
┌──────────────────────────────────────────────────────┐
│                  SESSION STORAGE                     │
│         (Browser storage - persists data)            │
└──────────────┬────────────────┬──────────────────────┘
               │                │
          Load │                │ Save
      (useEffect)          (useEffect)
               │                │
               ▼                │
        ┌─────────────────────┐ │
        │   employees[]       │ │
        │   (App.jsx state)   │◄┘
        └──────────┬──────────┘
                   │
    ┌──────────────┼──────────────┐
    │              │              │
    ▼              ▼              ▼
[CREATE]       [UPDATE]       [DELETE]
    │              │              │
    │              │              │
    └──────────────┴──────────────┘
                   │
                   ▼
         Update employees state
                   │
                   ▼
         Save to Session Storage
                   │
                   ▼
            Re-render UI
```

## CRUD Operations Flow

### CREATE (Add New Employee)

```
1. User fills form in EmployeeForm.jsx
2. User clicks "Add Employee"
3. Form data sent to App.jsx via onSubmit callback
4. App.jsx creates new employee object with unique ID
5. App.jsx adds to employees array
6. useEffect saves to session storage
7. EmployeeList re-renders with new employee
```

### READ (Display Employees)

```
1. App.jsx loads data from session storage (useEffect)
2. App.jsx passes employees[] to EmployeeList
3. EmployeeList maps through employees
4. EmployeeCard component created for each employee
5. Each card displays employee information
```

### UPDATE (Edit Employee)

```
1. User clicks "Edit" button on EmployeeCard
2. Card calls onEdit callback (passed from App.jsx)
3. App.jsx sets editingEmployee state
4. EmployeeForm receives editingEmployee prop
5. Form auto-fills with employee data (useEffect)
6. User makes changes and clicks "Update"
7. App.jsx updates employee in array
8. useEffect saves to session storage
9. editingEmployee set to null
10. UI updates with new data
```

### DELETE (Remove Employee)

```
1. User clicks "Delete" button on EmployeeCard
2. Card calls onDelete callback with employee ID
3. App.jsx shows confirmation dialog
4. If confirmed, filters employee out of array
5. useEffect saves updated array to session storage
6. EmployeeList re-renders without deleted employee
```

## Hooks Usage Breakdown

### useState Examples

```javascript
// In App.jsx
const [employees, setEmployees] = useState([]);
// Stores array of all employees

const [editingEmployee, setEditingEmployee] = useState(null);
// Stores employee being edited, null when not editing

// In EmployeeForm.jsx
const [formData, setFormData] = useState({
  name: '', email: '', phone: '', 
  position: '', department: '', salary: ''
});
// Stores form input values
```

### useEffect Examples

```javascript
// In App.jsx - Load data on component mount
useEffect(() => {
  const saved = sessionStorage.getItem('employees');
  if (saved) {
    setEmployees(JSON.parse(saved));
  }
}, []); // Empty array = runs once on mount

// In App.jsx - Save data when employees change
useEffect(() => {
  sessionStorage.setItem('employees', JSON.stringify(employees));
}, [employees]); // Runs when employees array changes

// In EmployeeForm.jsx - Update form when editing
useEffect(() => {
  if (editingEmployee) {
    setFormData(editingEmployee);
  }
}, [editingEmployee]); // Runs when editingEmployee changes
```

## Component Responsibilities

### App.jsx (Parent/Container)
- ✅ Manages all application state
- ✅ Handles all CRUD operations
- ✅ Manages session storage
- ✅ Passes data and callbacks to children
- ✅ Contains main UI structure

### EmployeeForm.jsx (Controlled Form)
- ✅ Manages form input state
- ✅ Handles form validation
- ✅ Displays add or edit mode
- ✅ Sends data back to parent
- ✅ Resets form after submit

### EmployeeList.jsx (List Container)
- ✅ Receives employees array
- ✅ Maps through employees
- ✅ Creates EmployeeCard for each
- ✅ Shows "No employees" message
- ✅ Passes callbacks to cards

### EmployeeCard.jsx (Presentational)
- ✅ Displays single employee data
- ✅ Shows employee avatar
- ✅ Provides edit/delete buttons
- ✅ Calls parent callbacks on actions
- ✅ No internal state (pure component)

## Props Flow Chart

```
App.jsx
  │
  ├─> EmployeeForm
  │     • onSubmit: function
  │     • editingEmployee: object | null
  │     • onCancelEdit: function
  │
  └─> EmployeeList
        • employees: array
        • onEdit: function
        • onDelete: function
        │
        └─> EmployeeCard (for each employee)
              • employee: object
              • onEdit: function
              • onDelete: function
```

## Session Storage Structure

```javascript
// Key: 'employees'
// Value: JSON string of array

// Example stored data:
[
  {
    "id": 1708123456789,
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "1234567890",
    "position": "Software Engineer",
    "department": "IT",
    "salary": "75000"
  },
  {
    "id": 1708123456790,
    "name": "Jane Smith",
    "email": "jane@example.com",
    "phone": "9876543210",
    "position": "HR Manager",
    "department": "HR",
    "salary": "65000"
  }
]
```

## File Dependencies

```
index.html
    └─> main.jsx
          └─> App.jsx
                ├─> App.css
                ├─> EmployeeForm.jsx
                ├─> EmployeeList.jsx
                │     └─> EmployeeCard.jsx
                │           └─> EmployeeCard.css
                │
                └─> bootstrap/dist/css/bootstrap.min.css
```

## Why This Structure?

### Separation of Concerns
- **App.jsx**: Business logic (CRUD)
- **Components**: UI and presentation
- **CSS files**: Styling only

### Reusability
- **EmployeeCard**: Used for each employee
- **EmployeeForm**: Used for both add and edit
- Can easily reuse components in other projects

### Single Responsibility
- Each component has one clear job
- Easy to find and fix bugs
- Easy to test individually

### Props Down, Events Up
- Data flows down via props
- Events flow up via callbacks
- Clean, predictable data flow

## State Management Strategy

```
                    APP STATE
                        │
         ┌──────────────┼──────────────┐
         │              │              │
    employees[]   editingEmployee   (other)
         │              │              │
         │              │              │
    ┌────▼────┐    ┌────▼────┐   ┌────▼────┐
    │ Display │    │  Form   │   │ Other   │
    │  List   │    │  Mode   │   │ Features│
    └─────────┘    └─────────┘   └─────────┘
```

## Key Concepts Demonstrated

1. **React Hooks** (useState, useEffect)
2. **Component Composition** (parent-child relationships)
3. **Props Passing** (data down, callbacks up)
4. **Session Storage** (browser data persistence)
5. **Controlled Components** (form inputs)
6. **Conditional Rendering** (edit mode, empty state)
7. **Event Handling** (onClick, onChange, onSubmit)
8. **Array Methods** (map, filter, spread operator)

---

This structure follows React best practices while keeping code simple and beginner-friendly! 🎓
