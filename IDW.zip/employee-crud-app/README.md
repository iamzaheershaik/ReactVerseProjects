# Employee CRUD Application

A simple Employee Management System built with React, Vite, and React Bootstrap. This beginner-friendly project demonstrates CRUD operations (Create, Read, Update, Delete) using Session Storage for data persistence.

## Features

✨ **Add New Employees** - Add employee details with name, email, phone, position, department, and salary
📝 **Edit Employees** - Update existing employee information
🗑️ **Delete Employees** - Remove employees from the system
💾 **Session Storage** - Data persists in the browser's session storage
🎨 **Beautiful UI** - Modern gradient design with React Bootstrap
📱 **Responsive** - Works on all device sizes

## Technologies Used

- **React 18** - JavaScript library for building user interfaces
- **Vite** - Fast build tool and development server
- **React Bootstrap** - Bootstrap components for React
- **React Icons** - Popular icon library
- **generate-unique-id** - NPM package for generating unique IDs
- **Session Storage** - Browser storage for data persistence

## Project Structure

```
employee-crud-app/
├── src/
│   ├── components/
│   │   ├── EmployeeForm.jsx      # Form component for add/edit
│   │   ├── EmployeeList.jsx      # List component to display all employees
│   │   ├── EmployeeCard.jsx      # Card component for individual employee
│   │   └── EmployeeCard.css      # Styles for employee card
│   ├── App.jsx                   # Main application component
│   ├── App.css                   # Global styles
│   └── main.jsx                  # Application entry point
├── index.html                    # HTML template
├── package.json                  # Dependencies and scripts
└── vite.config.js               # Vite configuration
```

## Installation & Setup

### Prerequisites
- Node.js (version 14 or higher)
- npm or yarn

### Steps to Run

1. **Navigate to the project folder**
   ```bash
   cd employee-crud-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   - The app will run on `http://localhost:5173`
   - Open this URL in your browser

## How to Use

### Adding an Employee
1. Fill in all the required fields in the form:
   - Full Name
   - Email
   - Phone Number
   - Position
   - Department (select from dropdown)
   - Salary
2. Click the "Add Employee" button
3. The employee will appear in the list below

### Editing an Employee
1. Click the "Edit" button on any employee card
2. The form will auto-fill with that employee's data
3. Make your changes
4. Click "Update Employee" to save
5. Click "Cancel" to stop editing

### Deleting an Employee
1. Click the "Delete" button on any employee card
2. Confirm the deletion in the popup
3. The employee will be removed

## Key Concepts for Beginners

### React Hooks Used

1. **useState** - Manages component state
   ```javascript
   const [employees, setEmployees] = useState([]);
   ```

2. **useEffect** - Handles side effects (loading/saving to session storage)
   ```javascript
   useEffect(() => {
     // Load from session storage
   }, []);
   ```

### Session Storage

- Data is saved in the browser's session storage
- Data persists while the browser tab is open
- Data is cleared when the tab is closed
- Located in: Browser DevTools > Application > Session Storage

### Component Structure

- **App.jsx** - Main parent component, handles all CRUD logic
- **EmployeeForm.jsx** - Reusable form for add/edit operations
- **EmployeeList.jsx** - Displays all employees in a grid
- **EmployeeCard.jsx** - Reusable card for each employee

## Customization

### Change Colors
Edit the gradient colors in `src/App.css`:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Add More Departments
Edit the department options in `src/components/EmployeeForm.jsx`:
```javascript
<option value="Your Department">Your Department</option>
```

### Change Form Fields
Add or remove fields in the form component and update the state accordingly.

## Build for Production

```bash
npm run build
```

The built files will be in the `dist` folder.

## Preview Production Build

```bash
npm run preview
```

## Troubleshooting

**Issue**: Dependencies not installing
**Solution**: Delete `node_modules` folder and `package-lock.json`, then run `npm install` again

**Issue**: Port 5173 already in use
**Solution**: Vite will automatically use the next available port

**Issue**: Data not persisting
**Solution**: Check if session storage is enabled in your browser

## Learning Resources

- [React Documentation](https://react.dev)
- [Vite Documentation](https://vitejs.dev)
- [React Bootstrap Documentation](https://react-bootstrap.github.io)
- [React Icons](https://react-icons.github.io/react-icons)

## License

This is a learning project. Feel free to use and modify as needed!

---

Happy Coding! 🚀
