import { useState, useEffect } from 'react';
import { Container } from 'react-bootstrap';
import { FaUsers } from 'react-icons/fa';
import generateUniqueId from 'generate-unique-id';
import EmployeeForm from './components/EmployeeForm';
import EmployeeList from './components/EmployeeList';
import './App.css';

function App() {
  
  // State to store all employees
  const [employees, setEmployees] = useState([]);
  
  // State to store which employee is being edited (null if not editing)
  const [editingEmployee, setEditingEmployee] = useState(null);

  // Load employees from session storage when app starts
  useEffect(() => {
    const savedEmployees = sessionStorage.getItem('employees');
    if (savedEmployees) {
      setEmployees(JSON.parse(savedEmployees));
    }
  }, []);

  // Save employees to session storage whenever employees change
  useEffect(() => {
    sessionStorage.setItem('employees', JSON.stringify(employees));
  }, [employees]);

  // Add or Update employee
  const handleSubmit = (employeeData) => {
    if (editingEmployee) {
      // UPDATE - if we are editing, update the existing employee
      const updatedEmployees = employees.map((emp) =>
        emp.id === editingEmployee.id 
          ? { ...employeeData, id: editingEmployee.id } 
          : emp
      );
      setEmployees(updatedEmployees);
      setEditingEmployee(null);
      alert('Employee updated successfully!');
    } else {
      // CREATE - add new employee with a unique ID using npm package
      const newEmployee = {
        ...employeeData,
        id: generateUniqueId() // Using generate-unique-id npm package
      };
      setEmployees([...employees, newEmployee]);
      alert('Employee added successfully!');
    }
  };

  // Edit employee - set the employee to be edited
  const handleEdit = (employee) => {
    setEditingEmployee(employee);
    // Scroll to top so user can see the form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Delete employee
  const handleDelete = (id) => {
    // Ask user to confirm before deleting
    if (window.confirm('Are you sure you want to delete this employee?')) {
      const filteredEmployees = employees.filter((emp) => emp.id !== id);
      setEmployees(filteredEmployees);
      alert('Employee deleted successfully!');
    }
  };

  // Cancel editing
  const handleCancelEdit = () => {
    setEditingEmployee(null);
  };

  return (
    <div className="app-container">
      
      {/* Header Section */}
      <div className="app-header">
        <h1>
          <FaUsers className="me-3" />
          Employee Management System
        </h1>
        <p>Manage your employees easily with this simple CRUD application</p>
      </div>

      {/* Form Section */}
      <div className="form-section">
        <h3>
          {editingEmployee ? 'Edit Employee' : 'Add New Employee'}
        </h3>
        <EmployeeForm 
          onSubmit={handleSubmit} 
          editingEmployee={editingEmployee}
          onCancelEdit={handleCancelEdit}
        />
      </div>

      {/* Employee List Section */}
      <div className="employee-list-section">
        <h3>
          All Employees ({employees.length})
        </h3>
        <EmployeeList 
          employees={employees}
          onEdit={handleEdit}
          onDelete={handleDelete}
        />
      </div>

    </div>
  );
}

export default App;
