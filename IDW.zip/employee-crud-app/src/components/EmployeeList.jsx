import React from 'react';
import { Row, Col } from 'react-bootstrap';
import { FaUserTie } from 'react-icons/fa';
import EmployeeCard from './EmployeeCard';

// This component shows all employees in a grid
function EmployeeList({ employees, onEdit, onDelete }) {
  
  // If no employees, show a message
  if (employees.length === 0) {
    return (
      <div className="no-employees">
        <div className="no-employees-icon">
          <FaUserTie />
        </div>
        <h4>No Employees Found</h4>
        <p>Add your first employee using the form above!</p>
      </div>
    );
  }

  return (
    <Row>
      {employees.map((employee) => (
        <Col key={employee.id} md={6} lg={4}>
          <EmployeeCard 
            employee={employee} 
            onEdit={onEdit} 
            onDelete={onDelete} 
          />
        </Col>
      ))}
    </Row>
  );
}

export default EmployeeList;
