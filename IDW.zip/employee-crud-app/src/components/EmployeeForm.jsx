import React, { useState, useEffect } from 'react';
import { Form, Button, Row, Col } from 'react-bootstrap';
import { FaUserPlus, FaSave, FaTimes } from 'react-icons/fa';

// This component is the form to add or edit employees
function EmployeeForm({ onSubmit, editingEmployee, onCancelEdit }) {
  
  // State to store form data
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    department: '',
    salary: ''
  });

  // When editingEmployee changes, fill the form with that employee's data
  useEffect(() => {
    if (editingEmployee) {
      setFormData(editingEmployee);
    } else {
      // Clear form if not editing
      setFormData({
        name: '',
        email: '',
        phone: '',
        position: '',
        department: '',
        salary: ''
      });
    }
  }, [editingEmployee]);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Simple validation - check if all fields are filled
    if (!formData.name || !formData.email || !formData.phone || 
        !formData.position || !formData.department || !formData.salary) {
      alert('Please fill all fields!');
      return;
    }

    // Send data to parent component
    onSubmit(formData);
    
    // Clear form after submit
    setFormData({
      name: '',
      email: '',
      phone: '',
      position: '',
      department: '',
      salary: ''
    });
  };

  // Handle cancel button
  const handleCancel = () => {
    onCancelEdit();
    setFormData({
      name: '',
      email: '',
      phone: '',
      position: '',
      department: '',
      salary: ''
    });
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Full Name *</Form.Label>
            <Form.Control
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter employee name"
            />
          </Form.Group>
        </Col>
        
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Email *</Form.Label>
            <Form.Control
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter email"
            />
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Phone Number *</Form.Label>
            <Form.Control
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="Enter phone number"
            />
          </Form.Group>
        </Col>
        
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Position *</Form.Label>
            <Form.Control
              type="text"
              name="position"
              value={formData.position}
              onChange={handleChange}
              placeholder="Enter position"
            />
          </Form.Group>
        </Col>
      </Row>

      <Row>
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Department *</Form.Label>
            <Form.Select 
              name="department" 
              value={formData.department}
              onChange={handleChange}
            >
              <option value="">Select Department</option>
              <option value="IT">IT</option>
              <option value="HR">HR</option>
              <option value="Finance">Finance</option>
              <option value="Marketing">Marketing</option>
              <option value="Sales">Sales</option>
              <option value="Operations">Operations</option>
            </Form.Select>
          </Form.Group>
        </Col>
        
        <Col md={6}>
          <Form.Group className="mb-3">
            <Form.Label>Salary *</Form.Label>
            <Form.Control
              type="number"
              name="salary"
              value={formData.salary}
              onChange={handleChange}
              placeholder="Enter salary"
            />
          </Form.Group>
        </Col>
      </Row>

      <div className="d-flex gap-2">
        <Button type="submit" className="btn-submit">
          {editingEmployee ? (
            <>
              <FaSave className="me-2" /> Update Employee
            </>
          ) : (
            <>
              <FaUserPlus className="me-2" /> Add Employee
            </>
          )}
        </Button>
        
        {editingEmployee && (
          <Button type="button" className="btn-cancel" onClick={handleCancel}>
            <FaTimes className="me-2" /> Cancel
          </Button>
        )}
      </div>
    </Form>
  );
}

export default EmployeeForm;
