import React from 'react';
import { Card, Button } from 'react-bootstrap';
import { FaEdit, FaTrash, FaEnvelope, FaPhone, FaBriefcase } from 'react-icons/fa';
import './EmployeeCard.css';

// This component shows one employee card
function EmployeeCard({ employee, onEdit, onDelete }) {
  return (
    <Card className="employee-card">
      <Card.Body>
        <div className="employee-header">
          <div className="employee-avatar">
            {employee.name.charAt(0).toUpperCase()}
          </div>
          <div className="employee-info">
            <h5 className="employee-name">{employee.name}</h5>
            <p className="employee-position">
              <FaBriefcase className="me-2" />
              {employee.position}
            </p>
          </div>
        </div>

        <div className="employee-details">
          <div className="detail-item">
            <FaEnvelope className="detail-icon" />
            <span>{employee.email}</span>
          </div>
          <div className="detail-item">
            <FaPhone className="detail-icon" />
            <span>{employee.phone}</span>
          </div>
          <div className="detail-item">
            <strong>Department:</strong>
            <span>{employee.department}</span>
          </div>
          <div className="detail-item">
            <strong>Salary:</strong>
            <span>${employee.salary}</span>
          </div>
        </div>

        <div className="employee-actions">
          <Button 
            variant="primary" 
            size="sm" 
            className="me-2"
            onClick={() => onEdit(employee)}
          >
            <FaEdit className="me-1" /> Edit
          </Button>
          <Button 
            variant="danger" 
            size="sm"
            onClick={() => onDelete(employee.id)}
          >
            <FaTrash className="me-1" /> Delete
          </Button>
        </div>
      </Card.Body>
    </Card>
  );
}

export default EmployeeCard;
