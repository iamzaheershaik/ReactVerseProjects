# 🎓 Code Explanation for Beginners

This document explains the key code snippets in the Employee CRUD application in simple terms.

---

## 1. useState Hook - Managing State

### What is State?
State is like a variable that React watches. When it changes, React automatically updates the screen.

### Example from App.jsx

```javascript
const [employees, setEmployees] = useState([]);
```

**Breaking it down:**
- `useState([])` - Creates a state variable with initial value as empty array
- `employees` - The actual data (current list of employees)
- `setEmployees` - Function to update the data
- When you call `setEmployees`, React re-renders the component

**Think of it like:**
```javascript
// Normal variable (React doesn't watch it)
let employees = [];
employees.push(newEmployee); // Screen won't update!

// State variable (React watches it)
const [employees, setEmployees] = useState([]);
setEmployees([...employees, newEmployee]); // Screen updates! ✅
```

---

## 2. useEffect Hook - Side Effects

### What are Side Effects?
Actions that happen "on the side" - like loading data, saving data, or setting timers.

### Example 1: Load data when app starts

```javascript
useEffect(() => {
  const savedEmployees = sessionStorage.getItem('employees');
  if (savedEmployees) {
    setEmployees(JSON.parse(savedEmployees));
  }
}, []); // ← Empty array means "run once when component loads"
```

**What happens:**
1. Component loads for the first time
2. useEffect runs automatically
3. Gets data from session storage
4. If data exists, converts from JSON string to array
5. Updates state with the data

**The empty array `[]` is important:**
- `[]` - Run once on mount
- `[employees]` - Run when employees changes
- No array - Run on every render (usually not what you want!)

### Example 2: Save data when it changes

```javascript
useEffect(() => {
  sessionStorage.setItem('employees', JSON.stringify(employees));
}, [employees]); // ← Runs whenever employees array changes
```

**What happens:**
1. Employee is added/edited/deleted
2. `employees` state changes
3. useEffect sees the change (because `employees` is in the array)
4. Converts array to JSON string
5. Saves to session storage

---

## 3. Spread Operator - Creating New Arrays

### The Problem with Direct Modification

```javascript
// ❌ WRONG - Mutating state directly
employees.push(newEmployee);
setEmployees(employees);
// React might not detect the change!
```

### The Solution - Spread Operator

```javascript
// ✅ CORRECT - Creating new array
setEmployees([...employees, newEmployee]);
```

**What `...` does:**
```javascript
const oldArray = [1, 2, 3];
const newArray = [...oldArray, 4];

// oldArray is still [1, 2, 3]
// newArray is [1, 2, 3, 4]

// It "spreads" all items from oldArray into newArray
```

**More examples:**

```javascript
// Add to beginning
setEmployees([newEmployee, ...employees]);

// Create copy
setEmployees([...employees]);

// Combine arrays
setEmployees([...employees1, ...employees2]);
```

---

## 4. Array Methods - Manipulating Data

### map() - Transform each item

```javascript
// Create EmployeeCard for each employee
{employees.map((employee) => (
  <EmployeeCard key={employee.id} employee={employee} />
))}
```

**What happens:**
- Goes through each employee in the array
- Creates an EmployeeCard component for each one
- `key={employee.id}` helps React track which card is which

**Think of it like:**
```javascript
employees = [emp1, emp2, emp3];

// map() transforms to:
[
  <EmployeeCard employee={emp1} />,
  <EmployeeCard employee={emp2} />,
  <EmployeeCard employee={emp3} />
]
```

### filter() - Remove items

```javascript
const filteredEmployees = employees.filter((emp) => emp.id !== id);
setEmployees(filteredEmployees);
```

**What happens:**
- Goes through each employee
- Keeps only employees where `emp.id !== id` is true
- Returns new array without the deleted employee

**Example:**
```javascript
employees = [
  { id: 1, name: "John" },
  { id: 2, name: "Jane" },
  { id: 3, name: "Bob" }
];

// Delete employee with id: 2
const filtered = employees.filter(emp => emp.id !== 2);

// Result:
filtered = [
  { id: 1, name: "John" },
  { id: 3, name: "Bob" }
];
```

---

## 5. Props - Passing Data Between Components

### What are Props?
Props are like function parameters, but for components.

### Passing Props Down

```javascript
// In App.jsx (Parent)
<EmployeeList 
  employees={employees}
  onEdit={handleEdit}
  onDelete={handleDelete}
/>
```

### Receiving Props

```javascript
// In EmployeeList.jsx (Child)
function EmployeeList({ employees, onEdit, onDelete }) {
  // Now you can use: employees, onEdit, onDelete
}
```

**Think of it like:**
```javascript
// Regular function
function greet(name, age) {
  return `Hi ${name}, you are ${age}`;
}
greet("John", 25);

// Component with props
function Greet({ name, age }) {
  return <p>Hi {name}, you are {age}</p>;
}
<Greet name="John" age={25} />
```

---

## 6. Conditional Rendering - Show/Hide Elements

### Using if-else

```javascript
if (employees.length === 0) {
  return <div>No employees found</div>;
}

return <EmployeeList employees={employees} />;
```

### Using ternary operator

```javascript
{editingEmployee ? (
  <h3>Edit Employee</h3>
) : (
  <h3>Add New Employee</h3>
)}
```

**Breakdown:**
- `editingEmployee ?` - If editingEmployee exists (truthy)
- `<h3>Edit Employee</h3>` - Show this
- `:` - Otherwise
- `<h3>Add New Employee</h3>` - Show this

### Using && operator

```javascript
{editingEmployee && (
  <Button onClick={handleCancel}>Cancel</Button>
)}
```

**What it means:**
- If `editingEmployee` is truthy, show the button
- If `editingEmployee` is null/false, don't show anything

---

## 7. Event Handlers - Responding to User Actions

### onChange - Input changes

```javascript
const handleChange = (e) => {
  const { name, value } = e.target;
  setFormData({
    ...formData,
    [name]: value
  });
};

<input name="email" onChange={handleChange} />
```

**What happens:**
1. User types in input field
2. onChange event fires
3. `e.target` is the input element
4. Gets input's `name` and `value`
5. Updates that specific field in formData

**Example:**
```javascript
// User types in email field
e.target = {
  name: "email",
  value: "john@example.com"
}

// Updates formData
setFormData({
  ...formData,
  email: "john@example.com"
});
```

### onSubmit - Form submission

```javascript
const handleSubmit = (e) => {
  e.preventDefault(); // ← Prevents page reload
  
  // Your code here
};

<form onSubmit={handleSubmit}>
```

**Why `e.preventDefault()`?**
- By default, forms reload the page when submitted
- We want to handle it in JavaScript instead
- So we prevent the default behavior

### onClick - Button clicks

```javascript
<Button onClick={() => onDelete(employee.id)}>
  Delete
</Button>
```

**Arrow function needed because:**
```javascript
// ❌ Wrong - calls function immediately
onClick={onDelete(employee.id)}

// ✅ Correct - creates function to call later
onClick={() => onDelete(employee.id)}
```

---

## 8. Destructuring - Cleaner Code

### Object Destructuring

```javascript
// Instead of this:
const name = employee.name;
const email = employee.email;
const phone = employee.phone;

// Do this:
const { name, email, phone } = employee;
```

### Props Destructuring

```javascript
// Instead of this:
function EmployeeCard(props) {
  return <div>{props.employee.name}</div>;
}

// Do this:
function EmployeeCard({ employee }) {
  return <div>{employee.name}</div>;
}
```

### Event Destructuring

```javascript
const handleChange = (e) => {
  // Instead of:
  const name = e.target.name;
  const value = e.target.value;
  
  // Do this:
  const { name, value } = e.target;
};
```

---

## 9. Session Storage - Browser Storage

### Saving Data

```javascript
// Convert JavaScript object/array to string
const jsonString = JSON.stringify(employees);

// Save to session storage
sessionStorage.setItem('employees', jsonString);
```

### Loading Data

```javascript
// Get string from session storage
const jsonString = sessionStorage.getItem('employees');

// Convert string back to JavaScript object/array
const employees = JSON.parse(jsonString);
```

**Important:**
- Session storage only stores strings
- That's why we need JSON.stringify() and JSON.parse()

**Example:**
```javascript
// JavaScript array
const data = [{ id: 1, name: "John" }];

// Convert to string for storage
const str = JSON.stringify(data);
// str = '[{"id":1,"name":"John"}]'

// Convert back to array
const arr = JSON.parse(str);
// arr = [{ id: 1, name: "John" }]
```

---

## 10. Creating Unique IDs

```javascript
const newEmployee = {
  ...employeeData,
  id: Date.now()
};
```

**What `Date.now()` does:**
- Returns current timestamp in milliseconds
- Example: 1708123456789
- Always unique (unless created in same millisecond)
- Simple way to generate IDs for learning projects

**For real projects, use:**
- UUID libraries
- Database auto-increment IDs
- More robust ID generation

---

## 11. Template Literals - String Interpolation

```javascript
// Old way
const message = 'Hello, ' + name + '!';

// New way (template literal)
const message = `Hello, ${name}!`;
```

**More examples:**
```javascript
const salary = 75000;
<span>Salary: ${salary}</span>

const count = employees.length;
<h3>All Employees ({count})</h3>
```

---

## 12. Arrow Functions - Modern JavaScript

### Traditional Function

```javascript
function handleEdit(employee) {
  setEditingEmployee(employee);
}
```

### Arrow Function

```javascript
const handleEdit = (employee) => {
  setEditingEmployee(employee);
};
```

### Short Arrow Function

```javascript
// One parameter, one line
const getName = employee => employee.name;

// No parameters
const sayHi = () => console.log('Hi!');

// Multiple lines
const handleSubmit = (data) => {
  console.log(data);
  saveData(data);
};
```

---

## 13. Import/Export - Organizing Code

### Exporting

```javascript
// At the end of EmployeeCard.jsx
export default EmployeeCard;
```

### Importing

```javascript
// In App.jsx
import EmployeeCard from './components/EmployeeCard';
```

**Named vs Default Export:**

```javascript
// Named export
export const Button = () => { ... };
import { Button } from './Button';

// Default export
export default Button;
import Button from './Button'; // Can name it anything
```

---

## Common Patterns in This Project

### Pattern 1: Controlled Form Input

```javascript
// State holds input value
const [name, setName] = useState('');

// Input displays state value
<input 
  value={name} 
  onChange={(e) => setName(e.target.value)} 
/>
```

### Pattern 2: Callback Props

```javascript
// Parent defines function
const handleDelete = (id) => { ... };

// Parent passes to child
<EmployeeCard onDelete={handleDelete} />

// Child calls it
<Button onClick={() => onDelete(employee.id)}>
```

### Pattern 3: Conditional Button

```javascript
{editingEmployee && (
  <Button onClick={handleCancel}>Cancel</Button>
)}
```

### Pattern 4: List Rendering

```javascript
{employees.map(employee => (
  <Component key={employee.id} data={employee} />
))}
```

---

## Debugging Tips

### console.log() is your friend!

```javascript
const handleSubmit = (data) => {
  console.log('Form data:', data);
  console.log('Current employees:', employees);
  
  // Your code...
};
```

### React DevTools
- Install React DevTools browser extension
- Inspect component props and state
- See component hierarchy

### Check Session Storage
1. Open browser DevTools (F12)
2. Go to "Application" tab
3. Click "Session Storage"
4. See your saved data

---

Remember: The best way to learn is by experimenting! Try changing values, breaking things, and fixing them. That's how you really understand code! 🚀
